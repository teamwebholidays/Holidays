<!doctype html>
<html lang="en">
    <!-- head -->
      <?php
        include('layout/head.php');
      ?>
    <!-- end head -->

    <body>
        <!-- header -->
          <?php
            include('layout/header.php');
          ?>
        <!-- end header-->

            <!-- content -->

            <!-- DAT TOUR -->
              <?php
                include('layout/dattour.php');
              ?>
            <!-- END DAT TOUR -->

            <!-- TOUR TIN TỨC DU LỊCH-->
             <?php
                include('layout/chitiettintuc.php');
              ?>
            <!-- END TOUR TIN TỨC DU LỊCH -->


            <!-- end content -->

            <!-- footer -->
              <?php
                include('layout/footer.php');
              ?>
            <!--end footer -->
           
           <!-- script -->
              <?php
                include('layout/script.php');
              ?>
            <!--end script -->
    </body>

</html>