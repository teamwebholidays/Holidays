<footer class="container-fluid main-footer">
    <div class="container">
    	<div class="row">

    		<div class="col-md-2 nd-footer">
    			<p class="tittle-footer">TRONG NƯỚC</p>
    			<ul>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    			</ul>
    		</div>

    		<div class="col-md-2 nd-footer">
    			<p class="tittle-footer">NƯỚC NGOÀI</p>
    			<ul>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    				<li><a href="">Hà Nội</a></li>
    			</ul>
    		</div>

    		<div class="col-md-2 nd-footer">

    			<p class="tittle-footer">THÔNG TIN</p>
    			<ul>
    				<li><a href="#">Giới thiệu</a></li>
    				<li><a href="#">Tin tức</a></li>
    				<li><a href="#">Tạp chí du lịch</a></li>
    				<li><a href="#">Cẩm nang du lịch</a></li>
    				<li><a href="#">Kinh nghiệm du lịch</a></li>
    				<li><a href="#">Video</a></li>
					<li><a href="#">Liên hệ</a></li>

    			</ul>
    		</div>

    		<div class="col-md-3 nd-footer">
    			<p class="tittle-footer">LIÊN HỆ</p>
    			<ul>
    				<li>123 Đường Nguyễn Văn Cừ</li>
    				<li>Điện thoại: 0909 123 456</li>
    				<li>Fax: 090313 123 13 </li>
    				<li>Email: info@abc.com</li>
    			</ul>


    			<p class="tittle-footer">CHẤP NHẬN THANH TOÁN</p>
				<div class="row-img-footer">
					<img src="<?php echo $path?>public/images/icon-back-logo/JCB.jpg" width="20%" height="20%" class="img-footer">
					<img src="<?php echo $path?>public/images/icon-back-logo/visa.jpg" width="20%" height="20%" class="img-footer">
					<img src="<?php echo $path?>public/images/icon-back-logo/mastercard.jpg" width="20%" height="20%" class="img-footer">
					<img src="<?php echo $path?>public/images/icon-back-logo/securecode_leadin.jpg" width="20%" height="20%" class="img-footer">
				</div>
    		</div>

    		<div class="col-md-3">
    			<p class="tittle-footer">KẾT NỐI VỚI CHÚNG TÔI</p>
    			<div class="row-img-footer">
					<a href="https://www.youtube.com/"><img src="<?php echo $path?>public/images/icon-back-logo/fb-icon.png" width="20%" height="20%" class="img-footer"></a>
					<a href="https://www.youtube.com/"><img src="<?php echo $path?>public/images/icon-back-logo/Logo_g+.png" width="20%" height="20%" class="img-footer"></a>
					<a href="https://www.youtube.com/"><img src="<?php echo $path?>public/images/icon-back-logo/logo-youtube.png" width="20%" height="20%" class="img-footer"></a>
					<a href="https://www.youtube.com/"><img src="<?php echo $path?>public/images/icon-back-logo/logo-twitter.png" width="20%" height="20%" class="img-footer"></a>
				</div>


				<p class="tittle-footer">ĐĂNG KÝ NHẬN TOUR MỚI</p>
				<div class="form-group form-footer">    
			      <input type="text" class="form-control" id="usr" placeholder="Email của bạn...">
			      <button class="btn">GỬI</button>
			    </div>

				<div style="margin-top: 30px">&nbsp;</div>
    		</div>
    	</div>
    </div>
    <div class="row footer-bottom">
        <div class="col-md-12">
            <p>Bản Quyền Thuộc về ABC @ 2018 - Số GPKD 12345678</p>
        </div>
    </div>
 </footer>