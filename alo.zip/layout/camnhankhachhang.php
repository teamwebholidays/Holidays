<div class="container-fluid maincamnhan">
	<div class="row" >
		<div class="col-md-12" align="center">
			<h3>CẢM NHẬN KHÁCH HÀNG</h3>
		</div>
	</div>
	<div class="row">
		<div class="col-md-2">
			<!--<img src="public/images/icon-back-logo/mai-01.png" width="100%">-->
		</div>

		<div class="col-md-8">
			<hr/>
				<div id="demo" class="carousel slide" data-ride="carousel" data-interval="5000" style="text-align: center ">
				  <div class="carousel-inner">
				    <div class="carousel-item active">
				      <p>29/03/2018 11:47:20</p>
				      <h6>CẢM NHẬN CỦA KHÁCH HÀNG TRANG HUỲNH NGUYÊN PHƯƠNG, TOUR ĐÀ NẴNG- HỘI AN - HUẾ THÁNG 03 NĂM 2018</h6>
				      <p>
						Dear Công ty VINATRIP,
						Kết thúc chuyến tour 4 ngày 3 đêm tại Đà Nẵng - Hội An - Huế, hai chị em tôi vẫn còn phấn khích vì có một chuyến đi thật thú vị và nhiều ấn tượng đẹp mà Công ty VINATRIP đã mang lại cho chúng tôi.
				      </p>
				    </div>
				    <div class="carousel-item">
				       <p>29/03/2018 11:47:20</p>
				      <h6>CẢM NHẬN CỦA KHÁCH HÀNG TRANG HUỲNH NGUYÊN PHƯƠNG, TOUR ĐÀ NẴNG- HỘI AN - HUẾ THÁNG 03 NĂM 2018</h6>
				      <p>
						Dear Công ty VINATRIP,
						Kết thúc chuyến tour 4 ngày 3 đêm tại Đà Nẵng - Hội An - Huế, hai chị em tôi vẫn còn phấn khích vì có một chuyến đi thật thú vị và nhiều ấn tượng đẹp mà Công ty VINATRIP đã mang lại cho chúng tôi.
				      </p>
				    </div>
				    <div class="carousel-item">
				       <p>29/03/2018 11:47:20</p>
				      <h6>CẢM NHẬN CỦA KHÁCH HÀNG TRANG HUỲNH NGUYÊN PHƯƠNG, TOUR ĐÀ NẴNG- HỘI AN - HUẾ THÁNG 03 NĂM 2018</h6>
				      <p>
						Dear Công ty VINATRIP,
						Kết thúc chuyến tour 4 ngày 3 đêm tại Đà Nẵng - Hội An - Huế, hai chị em tôi vẫn còn phấn khích vì có một chuyến đi thật thú vị và nhiều ấn tượng đẹp mà Công ty VINATRIP đã mang lại cho chúng tôi.
				      </p>
				    </div>
				  </div>
				</div>
			<hr/>
		</div>

		<div class="col-md-2">
			<!--<img src="public/images/icon-back-logo/mai-02.png" width="100%">-->
		</div>
	</div>
</div>