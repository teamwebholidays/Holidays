<div class="container-fluid" style="">
	<div class="container main_tinnoibat">
		<div class="row title_tinnoibat">
			<div class="col-md-12">
				<h2>TOUR GIÁ SỐC</h2>
			</div>
		</div>
		<div class="row" style="color:black; margin-top: 40px; padding-bottom: 30px">
			<div class="col-md-4" align="center" style="margin-bottom: 20px">
				<div class="card" style="width: 18rem">

				 <div>
					<div class="parent">
				        <div class="child bg-one">
				            <a href="#"></a>
				        </div>
				    </div>
					<div class="centered row"><a href="https://www.youtube.com/" style="text-decoration: none;color:#fb0">NGŨ HÀNH SƠN-HỘI AN-HUẾ-ĐỘNG THIÊN ĐƯỜNG-BÁN ĐẢO SƠN TRÀ</a></div>
				 </div>

				  <div class="card-body" style="background-color: rgb(172,214,60); color: white">
				  	<p style="text-decoration:line-through;">7.500.000 <sup>VNĐ</sup></p>
				    <h3 class="card-title">5.500.000 <sup>VNĐ</sup></h3>
				     <p class="card-text" style="color:#343434">
				     	<span class="fa fa-clock-o"></span>&nbsp; 4 Ngày &nbsp;
				     	<span class="fa fa-calendar"></span>&nbsp; Liên hệ</p>
				    <p class="card-text" style="color:#343434">Động Thiên Đường (được mệnh danh là Cung Điện trong lòng núi). Sau khi khám phá vẻ đẹp huyền ảo của những khối thạch nhũ...></p>
				    <a href="#" class="btn button-book">Book now</a>
				  </div>
				</div>
			</div>


			<div class="col-md-4" align="center" style="margin-bottom: 20px">
				<div class="card" style="width: 18rem;">

				 <div>
					<div class="parent">
				        <div class="child bg-true">
				            <a href="#"></a>
				        </div>
				    </div>
					<div class="centered row"><a href="https://www.youtube.com/" style="text-decoration: none;color:#fb0">CÙ LAO CHÀM</a></div>
				 </div>

				  <div class="card-body" style="background-color: rgb(172,214,60); color: white;">
				  	<p style="text-decoration:line-through;">7.500.000 <sup>VNĐ</sup></p>
				    <h3 class="card-title">500.000 <sup>VNĐ</sup></h3>
				     <p class="card-text" style="color:#343434">
				     	<span class="fa fa-clock-o"></span>&nbsp; 1 Ngày &nbsp;
				     	<span class="fa fa-calendar"></span>&nbsp; Hằng ngày</p>
				    <p class="card-text" style="color:#343434">Năm 2009, khi được UNESSCO công nhận là Khu Dự trữ Sinh quyển Thế giới, Cù Lao Chàm nhanh chóng ...</p>
				    <a href="#" class="btn button-book">Book now</a>
				  </div>
				</div>
			</div>



			<div class="col-md-4" align="center" style="margin-bottom: 20px">
				<div class="card" style="width: 18rem;">

				 <div>
					<div class="parent">
				        <div class="child bg-three">
				            <a href="#"></a>
				        </div>
				    </div>
					<div class="centered row"><a href="https://www.youtube.com/" style="text-decoration: none;color:#fb0">NGŨ HÀNH SƠN-HỘI AN-HUẾ-ĐỘNG THIÊN ĐƯỜNG-BÁN ĐẢO SƠN TRÀ</a></div>
				 </div>

				  <div class="card-body" style="background-color: rgb(172,214,60); color: white">
				  	<p style="text-decoration:line-through;">7.500.000 <sup>VNĐ</sup></p>
				    <h3 class="card-title">300.000 <sup>VNĐ</sup></h3>
				     <p class="card-text" style="color:#343434">
				     	<span class="fa fa-clock-o"></span>&nbsp; 4 Ngày &nbsp;
				     	<span class="fa fa-calendar"></span>&nbsp; Liên hệ</p>
				    <p class="card-text" style="color:#343434">Rừng dừa được ví von như là “Một góc Nam bộ trong lòng Phố cổ.”
					Hài hòa giữa vùng đất đô thị nhộn nhịp, Phố cổ cũng gắn...</p>
				    <a href="#" class="btn button-book">Book now</a>
				  </div>
				</div>
			</div>
		</div>
	</div>
</div>