<?php
    $path = "http://localhost:8888/Holidays_Web/";
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>VINATRIP</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $path?>public/Bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo $path?>public/font/font-awesome/css/font-awesome.min.css" />
    
    <!-- Custom styles for this template -->
    <link href="<?php echo $path?>public/css/style.css" rel="stylesheet">

    
    <script type="text/javascript" src="<?php echo $path?>public/js/jquery-3.2.1.min.js"></script>
	
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <script type="text/javascript" src="<?php echo $path?>public/js/app.js"></script>
</head>