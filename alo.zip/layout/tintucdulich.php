<div class="container">
	<div class="row mainttdulich">
		<div class="col-md-12">
			<h2>TIN TỨC DU LỊCH</h2>
		</div>
	</div>

	<!--Chổ cái row này mốt sẽ foreach từ csdl ra-->
	<div class="row">
		<!-- col hình -->
		<div class="col-md-4" align="center">
			<img src="public/images/tin_tuc/hinh-hoa-nhat.jpg" title="Mua-hoa-yeu-thuong" width="350em" height="230em">
		</div>
		<!-- col nội dung -->
		<div class="col-md-8 noidungttdulich">
			<h4>THƯƠNG NHỚ NHỮNG MÙA HOA NHẬT BẢN</h4>
			<p class="fa fa-calendar"><b>&nbsp; 21/3/2018</b></p> &nbsp;
			<p class="	fa fa-eye"><b>&nbsp; 50 lượt xem</b></p> <!-- chổ này mỗi lần load trang sẽ có update lượt xem trong csdl lên-->
			<hr/>
			<p><i>Nhật Bản ghi điểm trong lòng du khách bởi những mùa hoa xuân rực rỡ sắc màu. Mỗi loài mang một vẻ đẹp và nét cuốn hút riêng, đã tô điểm thêm sắc màu tươi mới của xứ Phù Tang. Hít hà hương hoa thơm ngát trong bầu không khí tuyệt diệu ấy hẳn sẽ là niềm ao ước trong mỗi chúng ta. Xuân này, hãy cùng gia đình đến thăm nước Nhật để hòa mình vào những thảm hoa tươi đẹp dưới đây nhé!</i></p>
			<a href="chi_tiet_tin_tuc.php">Xem tiếp ==></a> <!--cái này bấm sẽ nhảy ra trang chitiettintuc.php-->
		</div>
	</div>
	<!--Chổ cái row này mốt sẽ foreach từ csdl ra-->



	
</div>